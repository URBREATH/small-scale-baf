# baf-calculator

> Part of the [VC Map Project](https://github.com/virtualcitySYSTEMS/map-ui)
> describe your plugin

plugin relevant pages:

- [calculating BAF](https://www.berlin.de/sen/uvk/en/nature-and-green/landscape-planning/baf-biotope-area-factor/calculating-the-baf/)
- [examples fore BAF calculation](https://www.berlin.de/sen/uvk/en/nature-and-green/landscape-planning/baf-biotope-area-factor/calculation-examples/)
